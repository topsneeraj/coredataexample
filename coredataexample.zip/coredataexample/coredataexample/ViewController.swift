//
//  ViewController.swift
//  coredataexample
//
//  Created by TOPS on 10/9/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    
    
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    
    @IBOutlet weak var txtempmob: UITextField!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    @IBAction func btninsert(_ sender: Any) {
        
        
        let entity = NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context);
        
    
        entity.setValue(txtempname.text, forKey: "emp_name");
        entity.setValue(txtempadd.text, forKey: "emp_add");
        entity.setValue(txtempmob.text, forKey: "emp_mob");
        
        
        do {
            try context.save()
            clear();
            
        } catch  {
            
            
        }
        
    }
    
    
    func clear()  {
        
        txtempname.text = "";
        txtempadd.text = "";
        txtempmob.text = "";
        
        txtempname.becomeFirstResponder();
        
    }
    
    @IBAction func btnupdate(_ sender: Any) {
        
        
        let enity = NSEntityDescription.entity(forEntityName: "Employee", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = enity;
        
        let pred = NSPredicate(format: "emp_name =%@", txtempname.text!);
        
        request.predicate = pred;
        
        
        do {
            var arr  = try context.fetch(request);
            
            
            if arr.count > 0 {
                
                let obj = arr[0] as! NSManagedObject;
                
                obj.setValue(txtempname.text!, forKey: "emp_name");
                obj.setValue(txtempadd.text!, forKey: "emp_add");
                obj.setValue(txtempmob.text!, forKey: "emp_mob");
                
                do {
                    try  context.save()

                } catch  {
                    
                    
                }
                
                
            }
            
        } catch  {
            
            
        }
        
        
        

        
        
        
    }
    
    
    @IBAction func btndelete(_ sender: Any) {
        
        let enity = NSEntityDescription.entity(forEntityName: "Employee", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = enity;
        
        let pred = NSPredicate(format: "emp_name =%@", txtempname.text!);
        
        request.predicate = pred;
        
        
        do {
            var arr  = try context.fetch(request);
            
            
            if arr.count > 0 {
                
                let obj = arr[0] as! NSManagedObject;
                context.delete(obj);
                
                do {
                    try  context.save()
                } catch  {
                    
                    
                    
                }
               
                
            }
            
        } catch  {
            
            
        }
        
      

    }
    
    @IBAction func btnselect(_ sender: Any) {
        
        let enity = NSEntityDescription.entity(forEntityName: "Employee", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = enity;
        
        let pred = NSPredicate(format: "emp_name =%@", txtempname.text!);
        
        request.predicate = pred;
        
        
        do {
            var arr  = try context.fetch(request);
            
            
            if arr.count > 0 {
                
                let obj = arr[0] as! NSManagedObject;
                
                txtempname.text = obj.value(forKey: "emp_name") as! String?;
                txtempadd.text = obj.value(forKey: "emp_add") as! String?;
                txtempmob.text = obj.value(forKey: "emp_mob") as! String?
                
                
                
            }
            
        } catch  {
            
            
        }
        
        
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

